@FunctionalInterface
public interface MyInterface {
	public void message(String name, char symbol);
}
